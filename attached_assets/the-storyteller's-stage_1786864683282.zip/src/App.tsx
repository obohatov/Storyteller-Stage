import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Theater, BookOpen, User, Mail, ChevronRight, ArrowLeft, Globe, Star } from 'lucide-react';
import { translations, Language } from './translations';
import { cn } from './lib/utils';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [activePane, setActivePane] = useState<'plays' | 'tales' | null>(null);
  const t = translations[lang];

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'EN' },
    { code: 'uk', label: 'UA' },
    { code: 'nl', label: 'NL' },
  ];

  return (
    <div className="h-screen w-screen overflow-hidden bg-archive-dark flex relative">
      {/* Global Header */}
      <header className="absolute top-0 w-full z-50 px-8 h-24 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-4 pointer-events-auto">
          <div className="w-12 h-12 bg-archive-accent rounded-full flex items-center justify-center text-white shadow-lg">
            <BookOpen size={24} />
          </div>
          <h1 className={cn(
            "serif text-2xl font-bold transition-colors duration-500",
            activePane === 'tales' ? "text-archive-dark" : "text-white"
          )}>
            The Storyteller's Stage
          </h1>
        </div>

        <div className="flex items-center gap-6 pointer-events-auto">
          <div className="flex gap-2 bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/10">
            {languages.map((l) => (
              <button
                key={l.code}
                onClick={() => setLang(l.code)}
                className={cn(
                  "w-10 h-10 rounded-full text-xs font-bold transition-all",
                  lang === l.code ? "bg-archive-accent text-white" : "text-white/60 hover:text-white"
                )}
              >
                {l.code}
              </button>
            ))}
          </div>
          {activePane && (
            <button 
              onClick={() => setActivePane(null)}
              className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-archive-dark shadow-xl hover:scale-110 transition-transform"
            >
              <ArrowLeft size={24} />
            </button>
          )}
        </div>
      </header>

      {/* Pane 1: Plays */}
      <div 
        className={cn(
          "split-pane h-full relative overflow-hidden group cursor-pointer",
          activePane === 'plays' ? "w-full" : activePane === 'tales' ? "w-0" : "w-1/2 border-r border-white/10"
        )}
        onClick={() => !activePane && setActivePane('plays')}
      >
        <div className="absolute inset-0 bg-archive-dark z-0" />
        <img 
          src="https://picsum.photos/seed/theater/1200/1200?grayscale" 
          className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-overlay group-hover:scale-110 transition-transform duration-1000"
          referrerPolicy="no-referrer"
        />
        
        <div className="relative z-10 h-full flex flex-col items-center justify-center p-12 text-white">
          <AnimatePresence mode="wait">
            {!activePane ? (
              <motion.div 
                key="closed"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="text-center"
              >
                <Theater size={64} className="mx-auto mb-8 text-archive-accent" />
                <h2 className="text-6xl serif mb-4">{t.nav.plays}</h2>
                <p className="mono text-sm uppercase tracking-widest opacity-50">Explore the Stage</p>
              </motion.div>
            ) : activePane === 'plays' && (
              <motion.div 
                key="open"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-5xl pt-24 overflow-y-auto"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="pr-12">
                    <h2 className="text-7xl serif mb-8">{t.plays.title}</h2>
                    <p className="text-xl opacity-70 leading-relaxed mb-12">{t.plays.description}</p>
                    <div className="space-y-8">
                      <div className="p-8 border border-white/10 rounded-2xl bg-white/5">
                        <User size={32} className="mb-4 text-archive-accent" />
                        <h3 className="text-2xl serif mb-4">{t.about.title}</h3>
                        <p className="opacity-60 text-sm leading-relaxed">{t.about.content}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-6">
                    {t.plays.items.map((play, i) => (
                      <div key={i} className="p-8 border border-white/10 rounded-2xl hover:bg-white/5 transition-colors group/item">
                        <div className="flex justify-between items-start mb-4">
                          <span className="mono text-xs text-archive-accent uppercase tracking-widest">{play.genre}</span>
                          <ChevronRight className="opacity-0 group-hover/item:opacity-100 transition-opacity" />
                        </div>
                        <h3 className="text-3xl serif mb-2">{play.title}</h3>
                        <p className="opacity-50 text-sm">{play.summary}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Pane 2: Fairy Tales */}
      <div 
        className={cn(
          "split-pane h-full relative overflow-hidden group cursor-pointer",
          activePane === 'tales' ? "w-full" : activePane === 'plays' ? "w-0" : "w-1/2"
        )}
        onClick={() => !activePane && setActivePane('tales')}
      >
        <div className="absolute inset-0 bg-archive-light z-0" />
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-1/4 left-1/4"><Star size={100} className="text-archive-accent" /></div>
          <div className="absolute bottom-1/4 right-1/4"><Star size={150} className="text-archive-accent" /></div>
        </div>

        <div className="relative z-10 h-full flex flex-col items-center justify-center p-12 text-archive-dark">
          <AnimatePresence mode="wait">
            {!activePane ? (
              <motion.div 
                key="closed"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="text-center"
              >
                <BookOpen size={64} className="mx-auto mb-8 text-archive-accent" />
                <h2 className="text-6xl serif mb-4">{t.nav.fairyTales}</h2>
                <p className="mono text-sm uppercase tracking-widest opacity-50">Enter the Magic</p>
              </motion.div>
            ) : activePane === 'tales' && (
              <motion.div 
                key="open"
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-5xl pt-24 overflow-y-auto"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-6 order-2 md:order-1">
                    {t.fairyTales.items.map((tale, i) => (
                      <div key={i} className="p-8 border border-archive-dark/10 rounded-2xl hover:bg-archive-dark/5 transition-colors group/item">
                        <div className="flex justify-between items-start mb-4">
                          <BookOpen size={20} className="text-archive-accent" />
                          <ChevronRight className="opacity-0 group-hover/item:opacity-100 transition-opacity" />
                        </div>
                        <h3 className="text-3xl serif mb-2">{tale.title}</h3>
                        <p className="opacity-50 text-sm">{tale.summary}</p>
                      </div>
                    ))}
                  </div>
                  <div className="pl-12 order-1 md:order-2">
                    <h2 className="text-7xl serif mb-8">{t.fairyTales.title}</h2>
                    <p className="text-xl opacity-70 leading-relaxed mb-12">{t.fairyTales.description}</p>
                    <div className="p-8 bg-archive-accent/10 rounded-2xl border border-archive-accent/20">
                      <Mail size={32} className="mb-4 text-archive-accent" />
                      <h3 className="text-2xl serif mb-4">{t.contact.title}</h3>
                      <p className="text-sm opacity-70 mb-6">Interested in these stories? Let's connect.</p>
                      <button className="w-full py-4 bg-archive-dark text-white rounded-xl font-bold hover:scale-105 transition-transform">
                        {t.contact.send}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
