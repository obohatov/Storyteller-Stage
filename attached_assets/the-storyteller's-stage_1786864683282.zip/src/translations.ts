export type Language = 'en' | 'uk' | 'nl';

export interface Translation {
  nav: {
    plays: string;
    fairyTales: string;
    about: string;
    contact: string;
  };
  hero: {
    title: string;
    subtitle: string;
    cta: string;
  };
  plays: {
    title: string;
    description: string;
    items: {
      title: string;
      genre: string;
      summary: string;
    }[];
  };
  fairyTales: {
    title: string;
    description: string;
    items: {
      title: string;
      summary: string;
    }[];
  };
  about: {
    title: string;
    content: string;
  };
  contact: {
    title: string;
    name: string;
    email: string;
    message: string;
    send: string;
  };
}

export const translations: Record<Language, Translation> = {
  en: {
    nav: {
      plays: "Plays",
      fairyTales: "Fairy Tales",
      about: "About",
      contact: "Contact",
    },
    hero: {
      title: "Stories for the Stage and the Soul",
      subtitle: "Original plays for amateur theater and magical fairy tales for children.",
      cta: "Explore Works",
    },
    plays: {
      title: "Theatrical Plays",
      description: "Engaging scripts designed for amateur theater groups, focusing on human connection and community.",
      items: [
        { title: "The Echo of Silence", genre: "Drama", summary: "A story about a small village rediscovering its lost history." },
        { title: "Midsummer Mischief", genre: "Comedy", summary: "A lighthearted romp through a chaotic wedding preparation." },
      ],
    },
    fairyTales: {
      title: "Fairy Tales",
      description: "Whimsical stories written for my children, now shared with yours.",
      items: [
        { title: "The Star that Fell in the Well", summary: "A tiny star gets lost and finds friendship in the deep blue water." },
        { title: "The Dragon Who Loved Tea", summary: "A gentle dragon prefers Earl Grey over breathing fire." },
      ],
    },
    about: {
      title: "About the Author",
      content: "I am a writer based in the Netherlands, originally from Ukraine. My passion lies in creating worlds where everyone—from seasoned actors to wide-eyed children—can find a piece of themselves.",
    },
    contact: {
      title: "Get in Touch",
      name: "Name",
      email: "Email",
      message: "Message",
      send: "Send Message",
    },
  },
  uk: {
    nav: {
      plays: "П'єси",
      fairyTales: "Казки",
      about: "Про автора",
      contact: "Контакти",
    },
    hero: {
      title: "Історії для сцени та душі",
      subtitle: "Оригінальні п'єси для аматорського театру та магічні казки для дітей.",
      cta: "Переглянути роботи",
    },
    plays: {
      title: "Театральні п'єси",
      description: "Захоплюючі сценарії, розроблені для аматорських театральних груп, з акцентом на людські стосунки та громаду.",
      items: [
        { title: "Відлуння тиші", genre: "Драма", summary: "Історія про маленьке село, що заново відкриває свою втрачену історію." },
        { title: "Бешкет у літню ніч", genre: "Комедія", summary: "Весела пригода під час хаотичної підготовки до весілля." },
      ],
    },
    fairyTales: {
      title: "Казки",
      description: "Примхливі історії, написані для моїх дітей, якими я тепер ділюся з вашими.",
      items: [
        { title: "Зірка, що впала в колодязь", summary: "Крихітна зірка губиться і знаходить дружбу в глибокій синій воді." },
        { title: "Дракон, який любив чай", summary: "Лагідний дракон віддає перевагу чаю Ерл Грей замість того, щоб дихати вогнем." },
      ],
    },
    about: {
      title: "Про автора",
      content: "Я письменниця, що живе в Нідерландах, родом з України. Моя пристрасть — створювати світи, де кожен — від досвідчених акторів до дітей з великими очима — може знайти частинку себе.",
    },
    contact: {
      title: "Зв'яжіться зі мною",
      name: "Ім'я",
      email: "Електронна пошта",
      message: "Повідомлення",
      send: "Надіслати",
    },
  },
  nl: {
    nav: {
      plays: "Toneelstukken",
      fairyTales: "Sprookjes",
      about: "Over mij",
      contact: "Contact",
    },
    hero: {
      title: "Verhalen voor het Toneel en de Ziel",
      subtitle: "Originele toneelstukken voor amateurtoneel en magische sprookjes voor kinderen.",
      cta: "Ontdek Werken",
    },
    plays: {
      title: "Toneelstukken",
      description: "Boeiende scripts ontworpen voor amateurtoneelgroepen, met de focus op menselijke verbinding en gemeenschap.",
      items: [
        { title: "De Echo van Stilte", genre: "Drama", summary: "Een verhaal over een klein dorp dat zijn verloren geschiedenis herontdekt." },
        { title: "Midzomermishief", genre: "Komedie", summary: "Een vrolijke tocht door een chaotische huwelijksvoorbereiding." },
      ],
    },
    fairyTales: {
      title: "Sprookjes",
      description: "Speelse verhalen geschreven voor mijn kinderen, nu gedeeld met de uwe.",
      items: [
        { title: "De Ster die in de Put Viel", summary: "Een klein sterretje verdwaalt en vindt vriendschap in het diepblauwe water." },
        { title: "De Draak die van Thee Hield", summary: "Een vriendelijke draak verkiest Earl Grey boven vuurspuwen." },
      ],
    },
    about: {
      title: "Over de Auteur",
      content: "Ik ben een schrijfster gevestigd in Nederland, oorspronkelijk uit Oekraïne. Mijn passie ligt in het creëren van werelden waar iedereen—van ervaren acteurs tot kinderen met grote ogen—een stukje van zichzelf kan vinden.",
    },
    contact: {
      title: "Neem Contact Op",
      name: "Naam",
      email: "E-mail",
      message: "Bericht",
      send: "Verstuur Bericht",
    },
  },
};
